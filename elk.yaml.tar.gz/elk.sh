kubectl apply -f ./elasticsearch/elasticsearch.yaml 
kubectl apply -f ./logstash/logstash.yaml 
kubectl apply -f ./filebeat/filebeat_tcp.yaml
kubectl apply -f ./kibana/kibana.yaml 
